#include<iostream>
using namespace std;
int main(){
	int i;
	
	cout << "Enter a number: "; 	
	cin >> i;
	cout << "Square of number is: "<< i*i << endl;
return 0;	
}
